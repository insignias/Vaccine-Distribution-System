/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Person;

/**
 *
 * @author insignia
 */
public class InsuranceAdmin extends Person{
    
    private static int count;
    private int insuranceID;

    public InsuranceAdmin() {
        count++;
        insuranceID = count;
    }

    public int getInsuranceID() {
        return insuranceID;
    }

    public void setInsuranceID(int insuranceID) {
        this.insuranceID = insuranceID;
    }
    
    
    
}
