/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.WorkQueue;

import Business.UserAccount.UserAccount;
import java.util.Date;

/**
 *
 * @author relaince
 */
public abstract class WorkRequest {
    
    private String message;
    private UserAccount sender;
    private UserAccount receiver;
    private String status;
    private String ProcessDate;
    private Date resolveDate;
    private int requestID;
    private static int count;
    private int quantity;
    private String vaccineName;
    private String location;
    private String enterpriseType;
    private String enterpriseName;
    private String providerLocation;
    private String providerEnterpriseType;
    private String providerEnterpriseName;
    private String orderResult;

    public WorkRequest() {
        count++;
        requestID = count;
    }

    public String getOrderResult() {
        return orderResult;
    }

    public void setOrderResult(String orderResult) {
        this.orderResult = orderResult;
    }
    
    

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public UserAccount getSender() {
        return sender;
    }

    public void setSender(UserAccount sender) {
        this.sender = sender;
    }

    public UserAccount getReceiver() {
        return receiver;
    }

    public void setReceiver(UserAccount receiver) {
        this.receiver = receiver;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getProcessDate() {
        return ProcessDate;
    }

    public void setProcessDate(String ProcessDate) {
        this.ProcessDate = ProcessDate;
    }

    public Date getResolveDate() {
        return resolveDate;
    }

    public void setResolveDate(Date resolveDate) {
        this.resolveDate = resolveDate;
    }

    public int getRequestID() {
        return requestID;
    }

    public void setRequestID(int requestID) {
        this.requestID = requestID;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getVaccineName() {
        return vaccineName;
    }

    public void setVaccineName(String vaccineName) {
        this.vaccineName = vaccineName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getEnterpriseType() {
        return enterpriseType;
    }

    public void setEnterpriseType(String enterpriseType) {
        this.enterpriseType = enterpriseType;
    }

    public String getEnterpriseName() {
        return enterpriseName;
    }

    public void setEnterpriseName(String enterpriseName) {
        this.enterpriseName = enterpriseName;
    }

    public String getProviderLocation() {
        return providerLocation;
    }

    public void setProviderLocation(String providerLocation) {
        this.providerLocation = providerLocation;
    }

    public String getProviderEnterpriseType() {
        return providerEnterpriseType;
    }

    public void setProviderEnterpriseType(String providerEnterpriseType) {
        this.providerEnterpriseType = providerEnterpriseType;
    }

    public String getProviderEnterpriseName() {
        return providerEnterpriseName;
    }

    public void setProviderEnterpriseName(String providerEnterpriseName) {
        this.providerEnterpriseName = providerEnterpriseName;
    }
    
    
    
    @Override
    
    public String toString(){
        return getMessage();
    }
    
 
}
